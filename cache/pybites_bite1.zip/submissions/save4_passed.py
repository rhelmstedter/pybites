def sum_numbers(numbers=None):
    if numbers is None:
        return 5050
    else:
        return sum(numbers)
