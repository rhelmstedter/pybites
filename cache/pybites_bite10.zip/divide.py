def positive_divide(numerator, denominator):
    pass