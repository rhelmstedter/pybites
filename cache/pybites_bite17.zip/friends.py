def friends_teams():
    pass