from functools import lru_cache

def cached_fib(n):
    pass