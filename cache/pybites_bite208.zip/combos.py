def find_number_pairs(numbers, N=10):
    pass