from functools import wraps


def make_html(element):
    pass