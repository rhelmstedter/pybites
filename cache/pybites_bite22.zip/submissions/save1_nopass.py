from functools import wraps
"""I hope this works"""

def make_html(element):
    pass
