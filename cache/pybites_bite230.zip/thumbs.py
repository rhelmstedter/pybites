THUMBS_UP, THUMBS_DOWN = '👍', '👎'


class Thumbs:
    pass