from fibonacci import fib

# write one or more pytest functions below, they need to start with test_