import pytest

from workouts import print_workout_days


def test_print_workout_days():
    pass