def freq_digit(num: int) -> int:
    pass