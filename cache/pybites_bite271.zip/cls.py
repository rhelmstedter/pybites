import inspect


def get_classes(mod):
    """Return a list of all classes in module 'mod'"""
    pass