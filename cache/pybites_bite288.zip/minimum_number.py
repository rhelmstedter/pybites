from typing import List


def minimum_number(digits: List[int]) -> int:
    ...