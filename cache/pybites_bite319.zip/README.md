## [Bite 319. Identity and equality](https://codechalleng.es/bites/319/)

Good luck and please share you code in the Bite forums upon completion.

For questions use [our Slack](https://pybites.slack.com/archives/C6BGDQQ3B) (no spoilers please).

Check out our full catalogue of Bites of Py [here](https://codechalleng.es/bites/catalogue).

Enjoy and keep calm and code in Python!