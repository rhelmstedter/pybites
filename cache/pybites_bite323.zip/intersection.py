import functools
from typing import Iterable, Set, Any


def intersection(*args: Iterable) -> Set[Any]:
    pass