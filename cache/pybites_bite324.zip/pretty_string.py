import pprint
from typing import Any


def pretty_string(obj: Any) -> str:
    # TODO: your code
    pass