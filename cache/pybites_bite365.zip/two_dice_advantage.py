def original_expected_value(n: int) -> float:
    """Calculate the expected value of an n-sided die."""
    pass


def new_expected_value(n: int) -> float:
    """Calculate the expected value of an n-sided die when the player simulaneously rolls
    two dice and chooses the larger value.
    """
    pass