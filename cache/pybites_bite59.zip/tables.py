class MultiplicationTable:

    def __init__(self, length):
        """Create a 2D self._table of (x, y) coordinates and
           their calculations (form of caching)"""
        pass

    def __len__(self):
        """Returns the area of the table (len x* len y)"""
        pass

    def __str__(self):
        """Returns a string representation of the table"""
        pass

    def calc_cell(self, x, y):
        """Takes x and y coords and returns the re-calculated result"""
        pass