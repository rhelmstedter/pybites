class RecordScore():
    """Class to track a game's maximum score"""
    pass