def sequence_generator():
    pass